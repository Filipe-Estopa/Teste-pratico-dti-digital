import { calcTempoEntrega } from '../src/utils/calcTempo.js';

describe('Função calcTempoEntrega', () => {
  test('calcula corretamente para (3,4)', () => {
    const tempo = calcTempoEntrega(3, 4);
    expect(tempo).toBe(5);
  });

  test('arredonda para cima', () => {
    const tempo = calcTempoEntrega(2.2, 2.2);
    expect(tempo).toBe(4);
  });
});