import droneService from '../src/services/droneService.js';
import pedidoService from '../src/services/pedidoService.js';

describe('Capacidade do drone', () => {
  beforeEach(() => {
    pedidoService.pedidos.length = 0;
    droneService.drones.forEach(d => d.emUso = false);
  });

  test('rejeita pedido acima da capacidade', () => {
    const drone = droneService.drones[0];
    const pedido = {
      destino: { x: 10, y: 10 },
      peso: drone.capacidadeMaxima + 10,
      prioridade: 'alta'
    };

    const podeEntregar = droneService.podeEntregar(drone, pedido);
    expect(podeEntregar).toBe(false);
  });
});