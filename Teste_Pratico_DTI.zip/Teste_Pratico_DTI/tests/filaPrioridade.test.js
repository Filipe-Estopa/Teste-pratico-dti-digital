import pedidoService from '../src/services/pedidoService.js';

describe('Fila de pedidos por prioridade', () => {
  beforeEach(() => {
    pedidoService.pedidos.length = 0;
  });

  test('prioriza alta antes das demais', () => {
    pedidoService.criarPedido(1,1,1,'baixa');
    pedidoService.criarPedido(1,1,1,'alta');
    pedidoService.criarPedido(1,1,1,'media');

    const fila = pedidoService.listarPedidos().map(p => p.prioridade);
    expect(fila[0]).toBe('alta');
    expect(fila[1]).toBe('media');
    expect(fila[2]).toBe('baixa');
  });
});