const API_URL = location.origin; // assumes same origin (http://localhost:3000)
const singleForm = document.getElementById('singleForm');
const criarBtn = document.getElementById('criarBtn');
const sampleBtn = document.getElementById('sampleBtn');
const batchArea = document.getElementById('batchArea');
const batchSend = document.getElementById('batchSend');
const clearBatch = document.getElementById('clearBatch');
const pedidosList = document.getElementById('pedidosList');
const dronesList = document.getElementById('dronesList');
const metricasBox = document.getElementById('metricasBox');
const logBox = document.getElementById('logBox');
const map = document.getElementById('map');
const ctx = map.getContext('2d');
const lastUpdateEl = document.getElementById('lastUpdate');
const refreshNow = document.getElementById('refreshNow');
const toggleAuto = document.getElementById('toggleAuto');
const resetData = document.getElementById('resetData');

let auto = true;
let pollingInterval = 2000;
let timer = null;

function log(msg){
  const now = new Date().toLocaleTimeString();
  logBox.textContent = `[${now}] ${msg}\n` + logBox.textContent;
  if(logBox.textContent.length>2000) logBox.textContent = logBox.textContent.slice(0,2000);
}

singleForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  criarBtn.disabled = true;
  const x = parseFloat(document.getElementById('x').value);
  const y = parseFloat(document.getElementById('y').value);
  const peso = parseFloat(document.getElementById('peso').value);
  const prioridade = document.getElementById('prioridade').value;
  try{
    const res = await fetch(`${API_URL}/pedidos`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({x,y,peso,prioridade})
    });
    if(res.ok){
      const j = await res.json();
      log(`Pedido criado: ${j.id} • ${prioridade} • (${x},${y})`);
      atualizarTudo();
    } else {
      const err = await res.json().catch(()=>({error:'unknown'}));
      alert('Erro: ' + (err.error || JSON.stringify(err)));
    }
  }catch(err){
    alert('Erro de conexão: ' + err.message);
  } finally { criarBtn.disabled = false; }
});

sampleBtn.addEventListener('click', ()=>{
  batchArea.value = `[
  {"x":5,"y":5,"peso":2,"prioridade":"alta"},
  {"x":20,"y":10,"peso":3,"prioridade":"media"},
  {"x":15,"y":18,"peso":1,"prioridade":"baixa"},
  {"x":8,"y":7,"peso":2.5,"prioridade":"alta"}
]`;
});

batchSend.addEventListener('click', async ()=>{
  let v = batchArea.value.trim();
  if(!v) { alert('Cole um array JSON de pedidos no campo.'); return; }
  try{
    const arr = JSON.parse(v);
    if(!Array.isArray(arr)) throw new Error('Deve ser um array JSON');
    batchSend.disabled = true;
    for(const p of arr){
      await fetch(`${API_URL}/pedidos`, {
        method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(p)
      });
    }
    log(`Enviados ${arr.length} pedidos em lote`);
    batchArea.value = '';
    atualizarTudo();
  }catch(err){
    alert('JSON inválido: ' + err.message);
  } finally { batchSend.disabled = false; }
});

clearBatch.addEventListener('click', ()=>batchArea.value='');
refreshNow.addEventListener('click', atualizarTudo);

toggleAuto.addEventListener('click', ()=>{
  auto = !auto;
  toggleAuto.textContent = auto ? 'Parar auto-refresh' : 'Iniciar auto-refresh';
  if(auto) startPolling(); else stopPolling();
});

resetData.addEventListener('click', async ()=>{
  if(!confirm('Confirma limpar fila e métricas locais no servidor? (Reinicia apenas arrays in-memory)')) return;
  alert('Para resetar completamente, pare e reinicie o servidor. (não há endpoint de reset por segurança)');
});

async function fetchJson(path){
  const res = await fetch(path);
  if(!res.ok) throw new Error('HTTP ' + res.status);
  return res.json();
}

async function atualizarTudo(){
  try{
    const [pedidos, drones, metricas] = await Promise.all([
      fetchJson(`${API_URL}/pedidos`),
      fetchJson(`${API_URL}/drones`),
      fetchJson(`${API_URL}/metricas`)
    ]);
    renderPedidos(pedidos);
    renderDrones(drones);
    renderMetricas(metricas);
    renderMap(pedidos, drones);
    lastUpdateEl.textContent = new Date().toLocaleTimeString();
  }catch(err){
    log('Erro ao atualizar: ' + err.message);
  }
}

function renderPedidos(pedidos){
  if(pedidos.length===0) pedidosList.innerHTML = '<div class="small">Nenhum pedido na fila.</div>';
  else{
    pedidosList.innerHTML = pedidos.map(p=>`
      <div style="padding:6px;margin-bottom:6px;border-radius:8px;background:rgba(255,255,255,0.02)">
        <div><span class="chip">${p.prioridade.toUpperCase()}</span> <strong>${p.id.slice(0,8)}</strong></div>
        <div class="small">(${p.destino.x}, ${p.destino.y}) • ${p.peso}kg</div>
      </div>
    `).join('');
  }
}

function renderDrones(drones){
  if(drones.length===0) dronesList.innerHTML = '<div class="small">Nenhum drone registrado.</div>';
  else{
    dronesList.innerHTML = drones.map(d=>`
      <div style="padding:6px;margin-bottom:6px;border-radius:8px;background:rgba(255,255,255,0.02)">
        <div><strong>${d.id}</strong> • <span class="${d.emUso ? 'status-busy' : 'status-available'}">${d.emUso ? 'Em uso' : 'Disponível'}</span></div>
        <div class="small">Capacidade ${d.capacidadeMaxima}kg • Alcance ${d.alcanceMaximo}km</div>
      </div>
    `).join('');
  }
}

function renderMetricas(m){
  metricasBox.innerHTML = `
    <div style="padding:8px;border-radius:8px;background:rgba(255,255,255,0.02)">
      <div>Entregas realizadas: <strong>${m.entregasRealizadas}</strong></div>
      <div class="small">Tempo médio: <strong>${m.tempoMedioEntregaMinutos}</strong> min</div>
    </div>
  `;
}

function renderMap(pedidos, drones){
  const points = [];
  pedidos.forEach(p=>points.push([p.destino.x, p.destino.y]));
 
  let maxc = 10;
  for(const pt of points){ maxc = Math.max(maxc, Math.abs(pt[0]), Math.abs(pt[1])); }
  const padding = 20;
  const W = map.width, H = map.height;
  const scale = Math.min((W-2*padding)/(2*maxc), (H-2*padding)/(2*maxc));
  
  ctx.clearRect(0,0,W,H);
  ctx.fillStyle = '#021428';
  ctx.fillRect(0,0,W,H);
  ctx.strokeStyle = 'rgba(255,255,255,0.03)';
  ctx.lineWidth = 1;
 
  ctx.save();
  ctx.translate(W/2, H/2);
  const step = Math.max(1, Math.round(maxc/6));
  ctx.beginPath();
  for(let x=-maxc; x<=maxc; x+=step){
    ctx.moveTo(x*scale, -H);
    ctx.lineTo(x*scale, H);
  }
  for(let y=-maxc; y<=maxc; y+=step){
    ctx.moveTo(-W, y*scale);
    ctx.lineTo(W, y*scale);
  }
  ctx.stroke();
  ctx.restore();

  // Desenha a base no centro
  const baseX = W/2, baseY = H/2;
  ctx.fillStyle = '#ffd166';
  ctx.beginPath(); ctx.arc(baseX, baseY, 8, 0, Math.PI*2); ctx.fill();
  ctx.font = '12px Inter, Arial';
  ctx.fillStyle = '#cdeefd';
  ctx.fillText('Base (0,0)', baseX+12, baseY+5);

  pedidos.forEach((p, idx) => {
    const x = baseX + p.destino.x * scale;
    const y = baseY - p.destino.y * scale;
    ctx.fillStyle = '#06b6d4';
    ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#cdeefd';
    ctx.fillText(p.prioridade[0].toUpperCase() + ' ' + p.id.slice(0,6), x+8, y+4);
  });

  // Desenha os drones (posições visuais: espalhados pela base)
  drones.forEach((d, i) => {
    const angle = i * (Math.PI*2 / Math.max(1,drones.length));
    const radius = 40 + (i*20);
    const x = baseX + Math.cos(angle)*radius;
    const y = baseY + Math.sin(angle)*radius;
    ctx.fillStyle = d.emUso ? '#fb7185' : '#a7f3d0';
    ctx.beginPath(); ctx.arc(x, y, 8, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#001f21';
    ctx.fillText(d.id, x+10, y+4);
  });

  ctx.fillStyle = '#9fbcca';
  ctx.fillText(`Escala: 1 unidade ≈ ${ (1/scale).toFixed(2) } px (ajustada)`, 12, H-12);
}

function startPolling(){
  if(timer) clearInterval(timer);
  timer = setInterval(atualizarTudo, pollingInterval);
  atualizarTudo();
}

function stopPolling(){
  if(timer) clearInterval(timer);
  timer = null;
}

startPolling();
