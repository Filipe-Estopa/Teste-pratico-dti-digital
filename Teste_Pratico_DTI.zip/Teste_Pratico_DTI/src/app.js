import express from "express";
import router from "./routes/index.js";
import droneService from "./services/droneService.js";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

//Servir arquivos estáticos
app.use(express.static(path.join(__dirname, "../public")));

app.use("/", router);

//Loop simples a cada 2s para processar a fila
setInterval(() => {
  droneService.processarFila();
}, 2000);

app.listen(PORT, () => {
  console.log(`🚀 Drone API rodando em http://localhost:${PORT}`);
});
