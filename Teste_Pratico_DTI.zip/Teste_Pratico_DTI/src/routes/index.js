import express from "express";
import { criarPedido, listarPedidos } from "../controllers/pedidoController.js";
import { listarDrones } from "../controllers/droneController.js";
import { getMetricas } from "../controllers/metricasController.js";

const router = express.Router();

// Pedidos
router.post("/pedidos", criarPedido);
router.get("/pedidos", listarPedidos);

// Drones
router.get("/drones", listarDrones);

// Métricas
router.get("/metricas", getMetricas);

export default router;
