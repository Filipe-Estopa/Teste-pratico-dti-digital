import { randomUUID } from "crypto";

export default class Pedido {
  constructor(destino, peso, prioridade) {
    this.id = randomUUID();
    this.destino = destino;
    this.peso = peso;
    this.prioridade = prioridade; // "baixa", "media", "alta"
    this.criadoEm = Date.now();
    this.entregueEm = null;
  }
}
