export default class Coordenada {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  distanciaPara(outra) {
    const dx = outra.x - this.x;
    const dy = outra.y - this.y;
    return Math.sqrt(dx * dx + dy * dy);
  }
}
