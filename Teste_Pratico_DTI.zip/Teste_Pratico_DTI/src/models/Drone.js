export default class Drone {
  constructor(id, capacidadeMaxima, alcanceMaximo) {
    this.id = id;
    this.capacidadeMaxima = capacidadeMaxima;
    this.alcanceMaximo = alcanceMaximo;
    this.emUso = false;
    this.bateria = 100;
  }
}
