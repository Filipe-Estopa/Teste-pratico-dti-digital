export function calcTempoEntrega(x, y) {
  const distancia = Math.sqrt(x * x + y * y);
  return Math.ceil(distancia);
}