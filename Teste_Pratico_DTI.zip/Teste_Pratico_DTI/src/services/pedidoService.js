import Pedido from "../models/Pedido.js";
import Coordenada from "../models/Coordenada.js";

class PedidoService {
  constructor() {
    this.pedidos = []; // fila ordenada por prioridade
    this.entregasConcluidas = [];
    this.totalTempoEntrega = 0; // em minutos (simulado)
  }

  prioridadeToNumero(prioridade) {
    switch ((prioridade || "").toLowerCase()) {
      case "alta": return 1;
      case "media": return 2;
      case "baixa": return 3;
      default: return 3;
    }
  }

  criarPedido(x, y, peso, prioridade) {
    const destino = new Coordenada(x, y);
    const pedido = new Pedido(destino, peso, prioridade);
    this.pedidos.push(pedido);
    // ordenar a fila por prioridade (menor número = mais prioritário) e FIFO entre mesmas prioridades
    this.pedidos.sort((a, b) => {
      const pa = this.prioridadeToNumero(a.prioridade);
      const pb = this.prioridadeToNumero(b.prioridade);
      if (pa !== pb) return pa - pb;
      return a.criadoEm - b.criadoEm;
    });
    return pedido;
  }

  listarPedidos() {
    return this.pedidos;
  }

  retirarProximoPedido() {
    return this.pedidos.shift();
  }

  registrarEntrega(pedido, tempoEntrega) {
    pedido.entregueEm = Date.now();
    this.entregasConcluidas.push(pedido);
    this.totalTempoEntrega += tempoEntrega;
  }

  getMetricas() {
    const total = this.entregasConcluidas.length;
    const tempoMedio = total > 0 ? (this.totalTempoEntrega / total) : 0;
    return {
      entregasRealizadas: total,
      tempoMedioEntregaMinutos: Number(tempoMedio.toFixed(2))
    };
  }
}

export default new PedidoService();
