import Drone from "../models/Drone.js";
import pedidoService from "./pedidoService.js";

class DroneService {
  constructor() {
    this.drones = [
      new Drone("drone-1", 10, 30),
      new Drone("drone-2", 8, 25)
    ];
  }

  listarDrones() {
    return this.drones;
  }

  getDroneDisponivel() {
    return this.drones.find(d => !d.emUso);
  }

  podeEntregar(drone, pedido) {
    return pedido.peso <= drone.capacidadeMaxima;
  }

  async processarFila() {
    const drone = this.getDroneDisponivel();
    if (!drone) return;

    const pedido = pedidoService.retirarProximoPedido();
    if (!pedido) return;

    if (!this.podeEntregar(drone, pedido)) {
      console.log(`❌ Pedido ${pedido.id} excede capacidade do ${drone.id}. Pulando.`);
      return;
    }

    const base = { x: 0, y: 0 };
    const distancia = pedido.destino.distanciaPara(base);
    const tempoEntrega = Math.ceil(distancia);

    drone.emUso = true;
    console.log(`🚁 ${drone.id} saiu para entrega ${pedido.id} (distância ${distancia.toFixed(2)})`);

    await new Promise(resolve => setTimeout(resolve, 500));

    pedidoService.registrarEntrega(pedido, tempoEntrega);
    console.log(`✅ Entrega ${pedido.id} concluída em ${tempoEntrega} min`);

    drone.emUso = false;
  }
}

export default new DroneService();
