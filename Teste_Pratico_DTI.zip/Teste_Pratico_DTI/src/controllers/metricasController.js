import pedidoService from "../services/pedidoService.js";

export const getMetricas = (req, res) => {
  const metricas = pedidoService.getMetricas();
  res.json(metricas);
};
