import pedidoService from "../services/pedidoService.js";

export const criarPedido = (req, res) => {
  const { x, y, peso, prioridade } = req.body;
  if (typeof peso !== "number" || peso <= 0) {
    return res.status(400).json({ error: "Peso inválido" });
  }
  if (typeof x !== "number" || typeof y !== "number") {
    return res.status(400).json({ error: "Coordenadas inválidas" });
  }
  const pedido = pedidoService.criarPedido(x, y, peso, prioridade || "baixa");
  res.status(201).json(pedido);
};

export const listarPedidos = (req, res) => {
  res.json(pedidoService.listarPedidos());
};
