import droneService from "../services/droneService.js";

export const listarDrones = (req, res) => {
  res.json(droneService.listarDrones());
};
